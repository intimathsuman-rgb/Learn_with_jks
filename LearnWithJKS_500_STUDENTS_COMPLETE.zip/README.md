# Learn With JKS Complete v2.0

This is the consolidated Android project for Learn With JKS.

Included in one build:
- Firebase Phone OTP login with persistent session
- Student Corner
- Admin Corner with role check (`users/{uid}.role == admin`)
- Scheduled tests
- Test questions/options/correct answer
- Test submission and results
- Live class scheduling with Meet/Zoom link
- Recorded class links
- Study material: direct URL or Firebase Storage file upload
- User/result/material/class/test data in Firestore

Firebase project: learn-with-jks-a3d26
Android package: com.learnwithjks.app

IMPORTANT ONE-TIME FIREBASE SETUP:
1. Firebase Authentication -> Phone is enabled.
2. Create Firestore database.
3. Publish firestore.rules.
4. Publish storage.rules and ensure Storage is enabled.
5. After the first successful admin OTP login, open Firestore -> users -> that UID and set `role` to `admin` once. This is the only manual admin bootstrap step.

Test creation flow:
Admin -> Create Test -> save -> copy the Firestore test document ID -> Add Question -> paste ID.
Students see tests only while the current time is before the end time; opening before start is blocked.


## 500-student rollout
The Android app is designed so one admin can publish scheduled tests/classes/materials for many signed-in students. Firebase Firestore/Storage provide the shared backend. Live video capacity is controlled by the selected Meet/Zoom plan, not by the Android app.

Security note: the current Android test flow grades answers on the device and writes the result to Firestore. For high-stakes/anti-cheating exams, move grading to a trusted backend/Cloud Function before production use.

## One-time rules deployment
With Firebase CLI installed and logged in, from this project directory run:
`firebase use learn-with-jks-a3d26`
`firebase deploy --only firestore:rules,storage`

Do not give students Firebase console access. Only the admin account should manage tests, classes and materials.
