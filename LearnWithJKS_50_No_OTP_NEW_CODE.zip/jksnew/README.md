# Learn With JKS — No OTP source (initial 50-student pilot)

This is Android Studio/Gradle source code, not an APK.

## Login behavior
- Student enters a 10-digit Indian mobile number and taps OPEN APP.
- The app signs in anonymously with Firebase; the typed number is stored as a profile field, not verified by SMS.
- Enable Firebase Authentication > Sign-in method > Anonymous.

## Build
Repository root must contain `settings.gradle`, `build.gradle`, `app/`, and `.github/workflows/build.yml`. In GitHub, open Actions and run the build workflow. Download the APK from the successful run's Artifacts.

## Important security/setup notes
- Anonymous login does not prove ownership of the entered phone number.
- Configure Firestore and Storage security rules before using real student data.
- Admin access requires a trusted Firestore `users/{UID}` document with `role: "admin"`; do not grant this from the client app.
- This source has not been built/tested in this environment; a successful GitHub Actions run is still required.
