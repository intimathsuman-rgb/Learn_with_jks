# LEARN WITH JKS — Android App v1.0

यह पहला Android Studio project है। इसमें आपके दिए हुए REET Main L-2 SST HTML test को app के अंदर offline asset के रूप में चलाया गया है।

## अभी क्या काम करता है
- Android app launcher
- Portrait mobile layout
- JavaScript आधारित HTML test
- Timer, submit और result/review — HTML में मौजूद logic के अनुसार
- Telegram/बाहरी web links Android browser में खुलेंगे
- Test बिना server के भी app में चल सकता है

## अगला चरण
Online student registration/login, Test Series catalogue, result history और Admin Panel के लिए backend/API + database जोड़ना होगा।

## APK बनाना
Android Studio में यह folder खोलें और `Build > Build App Bundle(s) / APK(s) > Build APK(s)` चुनें।
