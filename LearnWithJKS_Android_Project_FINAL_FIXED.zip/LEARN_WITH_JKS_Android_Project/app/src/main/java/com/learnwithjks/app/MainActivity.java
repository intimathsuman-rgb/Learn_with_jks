package com.learnwithjks.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.content.Intent;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            webView = new WebView(this);
            setContentView(webView);

            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(true);
            s.setAllowContentAccess(true);
            s.setBuiltInZoomControls(false);
            s.setDisplayZoomControls(false);

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri u = request.getUrl();
                    if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, u));
                        } catch (Exception ignored) {}
                        return true;
                    }
                    return false;
                }
            });

            webView.loadUrl("file:///android_asset/test.html");
        } catch (Throwable e) {
            TextView fallback = new TextView(this);
            fallback.setText("LEARN WITH JKS\n\nApp शुरू हो गया है, लेकिन WebView लोड नहीं हो पाया।\nकृपया Chrome/Android System WebView अपडेट करें।");
            fallback.setTextSize(18);
            fallback.setTextColor(Color.DKGRAY);
            fallback.setPadding(40, 80, 40, 40);
            fallback.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
            setContentView(fallback);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
