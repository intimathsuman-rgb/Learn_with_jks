package com.learnwithjks.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private void showHome() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48, 48, 48, 48);

        TextView title = new TextView(this);
        title.setText("LEARN WITH JKS");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setTextColor(Color.rgb(30, 30, 30));
        title.setGravity(Gravity.CENTER);

        TextView sub = new TextView(this);
        sub.setText("Hindi Educational Test App");
        sub.setTextSize(18);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 20, 0, 40);

        Button start = new Button(this);
        start.setText("START TEST");
        start.setTextSize(18);
        start.setOnClickListener(v -> openTestSafely());

        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        root.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void openTestSafely() {
        try {
            webView = new WebView(this);
            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(true);
            s.setAllowContentAccess(true);
            webView.setWebViewClient(new WebViewClient());
            setContentView(webView);
            webView.loadUrl("file:///android_asset/test.html");
        } catch (Throwable e) {
            showError();
        }
    }

    private void showError() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(40, 40, 40, 40);

        TextView msg = new TextView(this);
        msg.setText("LEARN WITH JKS\n\nTest page load nahi ho paaya.\nAap app ko band karke dobara khol sakte hain.");
        msg.setTextSize(18);
        msg.setGravity(Gravity.CENTER);

        Button home = new Button(this);
        home.setText("HOME");
        home.setOnClickListener(v -> showHome());

        root.addView(msg, new LinearLayout.LayoutParams(-1, -2));
        root.addView(home, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
