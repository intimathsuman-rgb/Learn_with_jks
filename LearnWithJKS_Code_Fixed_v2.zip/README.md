# Learn With JKS — 50 student starter

This is an Android source project (not an APK). It uses Firebase Anonymous Authentication so students can enter a 10-digit mobile number without OTP. The number is stored as a profile label and is NOT verified by SMS.

## Build on GitHub Actions
1. Extract this ZIP.
2. Replace the repository contents on `main` with these project files (do not upload the ZIP itself). Remove the old ZIP-searching workflow and old workflow file, then keep `.github/workflows/build.yml` from this project.
3. In Firebase Console → Authentication → Sign-in method, enable **Anonymous**.
4. Confirm `app/google-services.json` belongs to Firebase project `learn-with-jks-a3d26` and Android package `com.learnwithjks.app`.
5. Run Actions → Build Learn With JKS Complete APK. Download artifact `LearnWithJKS-Complete-APK` if the run succeeds.

## Important security notes
- No-OTP mode does not verify that a student owns the entered phone number.
- The app includes a client-side 50-user check for the starter version. It is not a race-proof enforcement mechanism; enforce the limit with trusted backend rules/Cloud Functions before real use.
- Admin access depends on a trusted Firestore `users/{uid}` document with `role: "admin"`. Never let clients write their own `role`; configure Firestore security rules before use with real students.
- Test, results, materials and classes require matching Firestore/Storage rules and database documents. Review and configure rules before production.


## Topic-wise test scheduling and admin approval update
- Admin can add Subject/Topic when creating a scheduled test.
- Admin can grant join permission by test document ID and the student's 10-digit mobile number after the student has logged in once.
- Students must have a `testAccess/{testId}_{uid}` document with `allowed: true` before the test can be opened.
- Deploy the included `firestore.rules` in Firebase Console before using this feature.
- Mobile number entry without OTP is not verified identity. This is a source update and has not been compiled or tested into an APK in this environment.
