package com.learnwithjks.app;

import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.annotation.NonNull;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.*;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.firestore.*;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private EditText phone;
    private boolean adminMode = false, signingIn = false;
    private TextView status;
    private static final int PICK_FILE = 41;
    private Uri pickedFile;
    private String pickedName = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        try { auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance(); storage=FirebaseStorage.getInstance(); }
        catch(Throwable t){ fatal("Firebase start nahi ho paaya: "+msg(t)); return; }
        if(auth.getCurrentUser()!=null) routeUser(); else roleChoice();
    }

    private int dp(int n){ return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    private TextView tv(String s,float z,boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextSize(z); v.setTextColor(Color.BLACK); if(bold)v.setTypeface(null,1); v.setPadding(dp(8),dp(8),dp(8),dp(8)); return v; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }
    private EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setPadding(dp(12),dp(4),dp(12),dp(4)); return e; }
    private LinearLayout root(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(20),dp(20),dp(20),dp(20)); return r; }
    private void setRoot(LinearLayout r){ ScrollView s=new ScrollView(this); s.addView(r); setContentView(s); }
    private void fatal(String s){ TextView t=tv("LEARN WITH JKS\n\n"+s,18,true); t.setGravity(Gravity.CENTER); setContentView(t); }
    private String msg(Throwable e){ String m=e==null?null:e.getMessage(); return (m==null||m.isEmpty())?(e==null?"Unknown error":e.getClass().getSimpleName()):m; }
    private String time(long x){ return new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date(x)); }
    private long pickDateTime(String title, long initial, RunnableAfter<Long> done){
        Calendar c=Calendar.getInstance(); if(initial>0)c.setTimeInMillis(initial);
        DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{ c.set(y,m,day); TimePickerDialog t=new TimePickerDialog(this,(vv,h,min)->{c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,min);c.set(Calendar.SECOND,0);done.run(c.getTimeInMillis());},c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),false);t.setTitle(title);t.show();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)); d.setTitle(title); d.show(); return 0;
    }
    interface RunnableAfter<T>{void run(T x);}

    private void roleChoice(){
        LinearLayout r=root(); TextView h=tv("LEARN WITH JKS",30,true); h.setGravity(17); r.addView(h); TextView sub=tv("Choose Login",20,true); sub.setGravity(17); r.addView(sub);
        Button st=btn("STUDENT LOGIN"); Button ad=btn("ADMIN LOGIN"); r.addView(st); r.addView(ad); r.addView(tv("Admin login tabhi milega jab Firebase Firestore me users/{UID} document ka role = admin ho.",14,false)); setRoot(r);
        st.setOnClickListener(v->{adminMode=false;login();}); ad.setOnClickListener(v->{adminMode=true;login();});
    }

    private void login(){
        LinearLayout r=root(); r.addView(tv("LEARN WITH JKS",28,true)); r.addView(tv(adminMode?"Admin Login":"Student Login",21,true));
        phone=input("Mobile number (10 digits)"); phone.setInputType(InputType.TYPE_CLASS_PHONE); r.addView(phone,new LinearLayout.LayoutParams(-1,dp(60)));
        Button enter=btn(adminMode?"CONTINUE TO ADMIN":"ENTER APP"); r.addView(enter);
        status=tv("OTP nahi lagega. Mobile number verify nahi hoga.",15,false); r.addView(status);
        Button back=btn("BACK"); r.addView(back); setRoot(r);
        enter.setOnClickListener(v->{
            String p=phone.getText().toString().replaceAll("[^0-9]", "");
            if(p.startsWith("91") && p.length()==12) p=p.substring(2);
            if(p.length()!=10){status.setText("10 digit mobile number likhein.");return;}
            enter.setEnabled(false); status.setText("App khol rahe hain...");
            final String mobile=p;
            if(auth.getCurrentUser()!=null){
                saveMobileAndRoute(mobile, enter); return;
            }
            auth.signInAnonymously().addOnCompleteListener(this, task->{
                if(!task.isSuccessful()) {enter.setEnabled(true);status.setText("Login error: "+msg(task.getException())+". Firebase Anonymous sign-in enable karein.");return;}
                saveMobileAndRoute(mobile, enter);
            });
        });
        back.setOnClickListener(v->roleChoice());
    }

    private void saveMobileAndRoute(String mobile, Button enter){
        FirebaseUser u=auth.getCurrentUser();
        if(u==null){enter.setEnabled(true);status.setText("Login session nahi mila.");return;}
        DocumentReference ref=db.collection("users").document(u.getUid());
        ref.get().addOnSuccessListener(existing->{
            if(!existing.exists()){
                db.collection("users").limit(50).get().addOnSuccessListener(all->{
                    if(all.size()>=50){auth.signOut();enter.setEnabled(true);status.setText("Filhaal 50 students ki limit poori ho gayi hai.");return;}
                    writeMobile(ref,mobile,enter);
                }).addOnFailureListener(e->{enter.setEnabled(true);status.setText("Student limit check error: "+msg(e));});
            } else writeMobile(ref,mobile,enter);
        }).addOnFailureListener(e->{enter.setEnabled(true);status.setText("User check error: "+msg(e));});
    }

    private void writeMobile(DocumentReference ref,String mobile,Button enter){
        Map<String,Object> p=new HashMap<>(); p.put("uid",auth.getCurrentUser().getUid()); p.put("phone",mobile); p.put("updatedAt",FieldValue.serverTimestamp());
        ref.set(p,SetOptions.merge()).addOnCompleteListener(t->{if(!t.isSuccessful()){enter.setEnabled(true);status.setText("User save error: "+msg(t.getException()));return;} routeUser();});
    }

    private void routeUser(){
        FirebaseUser u=auth.getCurrentUser(); if(u==null){roleChoice();return;}
        DocumentReference ref=db.collection("users").document(u.getUid());
        Map<String,Object> p=new HashMap<>(); p.put("uid",u.getUid()); if(u.getPhoneNumber()!=null && !u.getPhoneNumber().isEmpty()) p.put("phone",u.getPhoneNumber()); p.put("updatedAt",FieldValue.serverTimestamp());
        ref.set(p,SetOptions.merge()).addOnCompleteListener(x->ref.get().addOnSuccessListener(d->{String role=d.getString("role"); if(adminMode && !"admin".equalsIgnoreCase(role)){auth.signOut();fatal("Admin access denied. Firestore users/"+u.getUid()+" me role = admin set karein.");} else if("admin".equalsIgnoreCase(role)) adminHome(); else studentHome();}));
    }

    private void header(LinearLayout r,String title){ TextView h=tv(title,25,true);h.setGravity(17);r.addView(h);Button logout=btn("LOGOUT");r.addView(logout);logout.setOnClickListener(v->{auth.signOut();roleChoice();}); }

    private void studentHome(){
        LinearLayout r=root();header(r,"STUDENT CORNER");
        Button tests=btn("📝 TESTS / RESULTS"), classes=btn("🎥 LIVE & RECORDED CLASSES"), mat=btn("📚 STUDY MATERIAL"); r.addView(tests);r.addView(classes);r.addView(mat);setRoot(r);
        tests.setOnClickListener(v->studentTests()); classes.setOnClickListener(v->studentClasses()); mat.setOnClickListener(v->studentMaterials());
    }

    private void studentTests(){
        LinearLayout r=root(); header(r,"TESTS"); Button back=btn("← STUDENT CORNER");r.addView(back); TextView out=tv("Loading...",15,false);r.addView(out);setRoot(r);back.setOnClickListener(v->studentHome());
        db.collection("tests").get().addOnSuccessListener(q->{r.removeView(out); long now=System.currentTimeMillis(); for(DocumentSnapshot d:q.getDocuments()){long a=d.getLong("startAt")==null?0:d.getLong("startAt");long z=d.getLong("endAt")==null?Long.MAX_VALUE:d.getLong("endAt"); if(now<=z){String topic=d.getString("topic");r.addView(tv("Topic: "+(topic==null||topic.isEmpty()?"General":topic),14,false));Button b=btn(d.getString("title")+"\n"+time(a)+" - "+time(z));r.addView(b);b.setOnClickListener(v->{long clickNow=System.currentTimeMillis();if(clickNow<a){toast("Test abhi start nahi hua.");return;}if(clickNow>z){toast("Test ka samay khatam ho gaya.");return;}String uid=auth.getCurrentUser().getUid();db.collection("testAccess").document(d.getId()+"_"+uid).get().addOnSuccessListener(access->{if(access.exists()&&Boolean.TRUE.equals(access.getBoolean("allowed")))takeTest(d.getId(),d.getString("title"),a,z);else new AlertDialog.Builder(this).setMessage("Is test ke liye Admin ki permission zaroori hai.").setPositiveButton("OK",null).show();}).addOnFailureListener(e->toast("Permission check error: "+msg(e)));});}}}).addOnFailureListener(e->out.setText("Tests load error: "+msg(e)));
    }

    private void takeTest(String testId,String title,long start,long end){
        if(System.currentTimeMillis()<start){toast("Test abhi start nahi hua.");return;} if(System.currentTimeMillis()>end){toast("Test ka time khatam ho gaya.");return;}
        LinearLayout r=root();header(r,title);TextView state=tv("Questions loading...",15,false);r.addView(state);setRoot(r);
        db.collection("tests").document(testId).collection("questions").get().addOnSuccessListener(q->{r.removeView(state);List<RadioGroup> groups=new ArrayList<>();List<DocumentSnapshot> docs=q.getDocuments(); if(docs.isEmpty()){r.addView(tv("Is test me questions nahi hain.",16,false));return;} for(DocumentSnapshot d:docs){r.addView(tv(d.getString("question"),18,true));RadioGroup g=new RadioGroup(this);String[] opts={(String)d.get("o0"),(String)d.get("o1"),(String)d.get("o2"),(String)d.get("o3")};for(String o:opts){RadioButton rb=new RadioButton(this);rb.setText(o==null?"":o);g.addView(rb);}groups.add(g);r.addView(g);} Button submit=btn("SUBMIT TEST");r.addView(submit);submit.setOnClickListener(v->{int score=0;for(int i=0;i<groups.size();i++){int checked=groups.get(i).getCheckedRadioButtonId(); if(checked!=-1){View vv=groups.get(i).findViewById(checked);int idx=groups.get(i).indexOfChild(vv);Long cor=docs.get(i).getLong("correct");if(cor!=null&&idx==cor)score++;}} final int finalScore=score;final int totalQuestions=groups.size();Map<String,Object> res=new HashMap<>();res.put("uid",auth.getCurrentUser().getUid());res.put("testId",testId);res.put("testTitle",title);res.put("score",finalScore);res.put("total",totalQuestions);res.put("submittedAt",FieldValue.serverTimestamp());db.collection("results").add(res).addOnSuccessListener(x->{toast("Result saved: "+finalScore+" / "+totalQuestions);studentHome();}).addOnFailureListener(e->toast("Result save error: "+msg(e)));});}).addOnFailureListener(e->state.setText("Question load error: "+msg(e)));
    }

    private void studentClasses(){
        LinearLayout r=root();header(r,"LIVE & RECORDED CLASSES");Button back=btn("← STUDENT CORNER");r.addView(back);TextView s=tv("Loading...",15,false);r.addView(s);setRoot(r);back.setOnClickListener(v->studentHome());
        db.collection("classes").get().addOnSuccessListener(q->{r.removeView(s);for(DocumentSnapshot d:q.getDocuments()){String title=d.getString("title"),url=d.getString("meetUrl"),rec=d.getString("recordingUrl");r.addView(tv(title==null?"Class":title,18,true));Long st=d.getLong("startAt");if(st!=null)r.addView(tv(time(st),14,false));if(url!=null&&!url.isEmpty()){Button b=btn("OPEN LIVE CLASS");r.addView(b);b.setOnClickListener(v->open(url));}if(rec!=null&&!rec.isEmpty()){Button b=btn("OPEN RECORDING");r.addView(b);b.setOnClickListener(v->open(rec));}}}).addOnFailureListener(e->s.setText("Class load error: "+msg(e)));
    }

    private void studentMaterials(){
        LinearLayout r=root();header(r,"STUDY MATERIAL");Button back=btn("← STUDENT CORNER");r.addView(back);TextView s=tv("Loading...",15,false);r.addView(s);setRoot(r);back.setOnClickListener(v->studentHome());
        db.collection("materials").get().addOnSuccessListener(q->{r.removeView(s);for(DocumentSnapshot d:q.getDocuments()){String title=d.getString("title"),url=d.getString("url"),type=d.getString("type");Button b=btn((type==null?"Material":type)+": "+(title==null?"":title));r.addView(b);b.setOnClickListener(v->open(url));}}).addOnFailureListener(e->s.setText("Material load error: "+msg(e)));
    }

    private void adminHome(){
        LinearLayout r=root();header(r,"ADMIN CORNER");
        Button ct=btn("📝 CREATE TOPIC-WISE TEST"), aq=btn("➕ ADD QUESTION"), ap=btn("🔐 GIVE TEST PERMISSION"), cl=btn("🎥 SCHEDULE CLASS"), ma=btn("📚 ADD STUDY MATERIAL"), rs=btn("📊 VIEW RESULTS"), us=btn("👥 VIEW USERS");r.addView(ct);r.addView(aq);r.addView(ap);r.addView(cl);r.addView(ma);r.addView(rs);r.addView(us);setRoot(r);
        ct.setOnClickListener(v->createTest());aq.setOnClickListener(v->addQuestion());ap.setOnClickListener(v->grantTestAccess());cl.setOnClickListener(v->createClass());ma.setOnClickListener(v->addMaterial());rs.setOnClickListener(v->results());us.setOnClickListener(v->users());
    }

    private void grantTestAccess(){
        LinearLayout r=root();header(r,"GIVE TEST PERMISSION");Button back=btn("← ADMIN");r.addView(back);EditText testId=input("Test document ID");EditText mobile=input("Student mobile number (10 digits)");r.addView(testId);r.addView(mobile);r.addView(tv("Student ko pehle app me mobile number se login karna hoga.",14,false));Button grant=btn("ALLOW STUDENT TO JOIN");r.addView(grant);setRoot(r);back.setOnClickListener(v->adminHome());
        grant.setOnClickListener(v->{String tid=testId.getText().toString().trim();String ph=mobile.getText().toString().replaceAll("[^0-9]","");if(ph.startsWith("91")&&ph.length()==12)ph=ph.substring(2);if(tid.isEmpty()||ph.length()!=10){toast("Test ID aur 10 digit mobile number bharein.");return;}db.collection("users").whereEqualTo("phone",ph).limit(1).get().addOnSuccessListener(users->{if(users.isEmpty()){toast("Student nahi mila. Student ko pehle app login karna hoga.");return;}String uid=users.getDocuments().get(0).getId();Map<String,Object> a=new HashMap<>();a.put("testId",tid);a.put("uid",uid);a.put("allowed",true);a.put("grantedBy",auth.getCurrentUser().getUid());a.put("grantedAt",FieldValue.serverTimestamp());db.collection("testAccess").document(tid+"_"+uid).set(a).addOnSuccessListener(x->{toast("Permission de di gayi.");adminHome();}).addOnFailureListener(e->toast("Permission save error: "+msg(e)));}).addOnFailureListener(e->toast("Student search error: "+msg(e)));});
    }

    private void createTest(){
        LinearLayout r=root();header(r,"CREATE TEST");Button back=btn("← ADMIN");r.addView(back);EditText topic=input("Subject / Topic (e.g. Rajasthan Geography - Rivers)");EditText title=input("Test title");r.addView(topic);r.addView(title);TextView st=tv("Start: not selected",14,false),en=tv("End: not selected",14,false);r.addView(st);Button sb=btn("SET START TIME");r.addView(sb);r.addView(en);Button eb=btn("SET END TIME");r.addView(eb);Button save=btn("SAVE TEST");r.addView(save);setRoot(r);back.setOnClickListener(v->adminHome());final long[] a={0},z={0};sb.setOnClickListener(v->pickDateTime("Test start",System.currentTimeMillis(),x->{a[0]=x;st.setText("Start: "+time(x));}));eb.setOnClickListener(v->pickDateTime("Test end",System.currentTimeMillis()+3600000,x->{z[0]=x;en.setText("End: "+time(x));}));save.setOnClickListener(v->{if(title.getText().toString().trim().isEmpty()||a[0]==0||z[0]==0){toast("Title, start aur end bharna zaroori hai.");return;}Map<String,Object> m=new HashMap<>();m.put("title",title.getText().toString().trim());m.put("topic",topic.getText().toString().trim());m.put("startAt",a[0]);m.put("endAt",z[0]);m.put("published",true);m.put("createdBy",auth.getCurrentUser().getUid());m.put("createdAt",FieldValue.serverTimestamp());db.collection("tests").add(m).addOnSuccessListener(x->{toast("Test created. Ab ADD QUESTION se questions add karein.");adminHome();}).addOnFailureListener(e->toast("Save error: "+msg(e)));});
    }

    private void addQuestion(){
        LinearLayout r=root();header(r,"ADD QUESTION");Button back=btn("← ADMIN");r.addView(back);EditText id=input("Test ID");EditText q=input("Question");EditText[] o={input("Option 1"),input("Option 2"),input("Option 3"),input("Option 4")};r.addView(id);r.addView(q);for(EditText e:o)r.addView(e);EditText cor=input("Correct option number: 1-4");cor.setInputType(InputType.TYPE_CLASS_NUMBER);r.addView(cor);Button save=btn("SAVE QUESTION");r.addView(save);r.addView(tv("Test ID TESTS list me Firestore document ID hoga.",13,false));setRoot(r);back.setOnClickListener(v->adminHome());save.setOnClickListener(v->{try{int c=Integer.parseInt(cor.getText().toString())-1;if(c<0||c>3)throw new Exception();Map<String,Object> m=new HashMap<>();m.put("question",q.getText().toString());for(int i=0;i<4;i++)m.put("o"+i,o[i].getText().toString());m.put("correct",c);db.collection("tests").document(id.getText().toString().trim()).collection("questions").add(m).addOnSuccessListener(x->{toast("Question saved.");adminHome();}).addOnFailureListener(e->toast("Save error: "+msg(e)));}catch(Exception e){toast("Correct option 1 se 4 tak dein.");}});
    }

    private void createClass(){
        LinearLayout r=root();header(r,"SCHEDULE CLASS");Button back=btn("← ADMIN");r.addView(back);EditText title=input("Class title");EditText meet=input("Live class link (Meet/Zoom)");EditText rec=input("Recording link (optional)");r.addView(title);r.addView(meet);r.addView(rec);TextView st=tv("Time: not selected",14,false);r.addView(st);Button pick=btn("SET CLASS TIME");r.addView(pick);Button save=btn("SAVE CLASS");r.addView(save);setRoot(r);back.setOnClickListener(v->adminHome());final long[] t={0};pick.setOnClickListener(v->pickDateTime("Class time",System.currentTimeMillis(),x->{t[0]=x;st.setText("Time: "+time(x));}));save.setOnClickListener(v->{if(title.getText().toString().trim().isEmpty()||t[0]==0){toast("Title aur time zaroori hai.");return;}Map<String,Object> m=new HashMap<>();m.put("title",title.getText().toString().trim());m.put("meetUrl",meet.getText().toString().trim());m.put("recordingUrl",rec.getText().toString().trim());m.put("startAt",t[0]);m.put("createdAt",FieldValue.serverTimestamp());db.collection("classes").add(m).addOnSuccessListener(x->{toast("Class scheduled.");adminHome();}).addOnFailureListener(e->toast("Save error: "+msg(e)));});
    }

    private void addMaterial(){
        LinearLayout r=root();header(r,"ADD STUDY MATERIAL");Button back=btn("← ADMIN");r.addView(back);EditText title=input("Material title");EditText type=input("Type: PDF / Notes / Image / Video");EditText url=input("Or direct URL (optional)");Button pick=btn("SELECT FILE");TextView chosen=tv("No file selected",14,false);Button save=btn("SAVE MATERIAL");r.addView(title);r.addView(type);r.addView(url);r.addView(pick);r.addView(chosen);r.addView(save);setRoot(r);back.setOnClickListener(v->adminHome());pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_FILE);});save.setOnClickListener(v->{if(title.getText().toString().trim().isEmpty()){toast("Title zaroori hai.");return;}if(pickedFile!=null){StorageReference ref=storage.getReference().child("materials/"+System.currentTimeMillis()+"_"+pickedName);ref.putFile(pickedFile).continueWithTask(t->{if(!t.isSuccessful())throw t.getException();return ref.getDownloadUrl();}).addOnSuccessListener(u->{saveMaterial(title.getText().toString(),type.getText().toString(),u.toString());}).addOnFailureListener(e->toast("Upload error: "+msg(e)));}else if(!url.getText().toString().trim().isEmpty())saveMaterial(title.getText().toString(),type.getText().toString(),url.getText().toString().trim());else toast("File ya URL dein.");});
    }
    private void saveMaterial(String t,String type,String url){Map<String,Object> m=new HashMap<>();m.put("title",t.trim());m.put("type",type.trim());m.put("url",url);m.put("createdAt",FieldValue.serverTimestamp());db.collection("materials").add(m).addOnSuccessListener(x->{toast("Material saved.");pickedFile=null;adminHome();}).addOnFailureListener(e->toast("Save error: "+msg(e)));}

    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK_FILE&&c==RESULT_OK&&d!=null&&d.getData()!=null){pickedFile=d.getData();pickedName="selected_file";try{android.database.Cursor cur=getContentResolver().query(pickedFile,null,null,null,null);if(cur!=null){int n=cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(cur.moveToFirst()&&n>=0)pickedName=cur.getString(n);cur.close();}}catch(Exception ignored){}toast("File selected: "+pickedName);}}

    private void results(){
        LinearLayout r=root();header(r,"RESULTS");Button back=btn("← ADMIN");r.addView(back);TextView s=tv("Loading...",15,false);r.addView(s);setRoot(r);back.setOnClickListener(v->adminHome());db.collection("results").get().addOnSuccessListener(q->{r.removeView(s);for(DocumentSnapshot d:q.getDocuments())r.addView(tv(d.getString("testTitle")+" | "+d.getString("uid")+" | "+d.getLong("score")+"/"+d.getLong("total"),15,false));}).addOnFailureListener(e->s.setText("Result load error: "+msg(e)));
    }
    private void users(){
        LinearLayout r=root();header(r,"USERS");Button back=btn("← ADMIN");r.addView(back);TextView s=tv("Loading...",15,false);r.addView(s);setRoot(r);back.setOnClickListener(v->adminHome());db.collection("users").get().addOnSuccessListener(q->{r.removeView(s);for(DocumentSnapshot d:q.getDocuments())r.addView(tv((d.getString("phone")==null?"":d.getString("phone"))+" | role="+(d.getString("role")==null?"student":d.getString("role")),15,false));}).addOnFailureListener(e->s.setText("Users load error: "+msg(e)));
    }

    private void open(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){toast("Link open nahi hua.");}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
