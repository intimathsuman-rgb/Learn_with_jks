# Learn With JKS - Firebase OTP Stage

This source is the first Firebase integration stage for Learn With JKS.

Included:
- Firebase Phone Authentication
- Mobile number + OTP login
- Persistent Firebase login session
- Basic logged-in Student Corner placeholder
- Logout
- targetSdk 35
