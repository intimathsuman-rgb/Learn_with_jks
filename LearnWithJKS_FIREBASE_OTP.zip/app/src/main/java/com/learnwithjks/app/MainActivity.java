package com.learnwithjks.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private FirebaseAuth auth;
    private EditText phoneInput;
    private EditText otpInput;
    private Button sendOtpButton;
    private Button verifyOtpButton;
    private TextView statusText;
    private String verificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        auth = FirebaseAuth.getInstance();

        if (auth.getCurrentUser() != null) {
            showLoggedInScreen();
        } else {
            showLoginScreen();
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, float size, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(Color.BLACK);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setPadding(dp(8), dp(8), dp(8), dp(8));
        return tv;
    }

    private void showLoginScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));

        TextView title = text("LEARN WITH JKS", 28, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = text("Student Login", 20, true);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        phoneInput = new EditText(this);
        phoneInput.setHint("Mobile number (+91XXXXXXXXXX)");
        phoneInput.setInputType(InputType.TYPE_CLASS_PHONE);
        root.addView(phoneInput, new LinearLayout.LayoutParams(-1, dp(60)));

        sendOtpButton = new Button(this);
        sendOtpButton.setText("Send OTP");
        root.addView(sendOtpButton, new LinearLayout.LayoutParams(-1, dp(56)));

        otpInput = new EditText(this);
        otpInput.setHint("Enter 6-digit OTP");
        otpInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        otpInput.setVisibility(View.GONE);
        root.addView(otpInput, new LinearLayout.LayoutParams(-1, dp(60)));

        verifyOtpButton = new Button(this);
        verifyOtpButton.setText("Verify OTP");
        verifyOtpButton.setVisibility(View.GONE);
        root.addView(verifyOtpButton, new LinearLayout.LayoutParams(-1, dp(56)));

        statusText = text("OTP login is ready.", 15, false);
        statusText.setGravity(Gravity.CENTER);
        root.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);

        sendOtpButton.setOnClickListener(v -> sendOtp());
        verifyOtpButton.setOnClickListener(v -> verifyOtp());
    }

    private void sendOtp() {
        String phone = phoneInput.getText().toString().trim();

        if (!phone.startsWith("+")) {
            Toast.makeText(this, "Number country code ke saath likhein, jaise +91XXXXXXXXXX", Toast.LENGTH_LONG).show();
            return;
        }

        sendOtpButton.setEnabled(false);
        statusText.setText("OTP bheja ja raha hai...");

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(auth)
                        .setPhoneNumber(phone)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {
                                signInWithCredential(credential);
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                sendOtpButton.setEnabled(true);
                                statusText.setText("OTP bhejne mein problem: " + e.getMessage());
                            }

                            @Override
                            public void onCodeSent(@NonNull String id,
                                                   @NonNull PhoneAuthProvider.ForceResendingToken token) {
                                verificationId = id;
                                otpInput.setVisibility(View.VISIBLE);
                                verifyOtpButton.setVisibility(View.VISIBLE);
                                sendOtpButton.setEnabled(true);
                                statusText.setText("OTP aa gaya. OTP enter karke Verify dabayein.");
                            }
                        })
                        .build();

        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void verifyOtp() {
        if (verificationId == null) {
            statusText.setText("Pehle Send OTP dabayein.");
            return;
        }

        String code = otpInput.getText().toString().trim();
        if (code.length() != 6) {
            Toast.makeText(this, "6 digit OTP enter karein.", Toast.LENGTH_SHORT).show();
            return;
        }

        verifyOtpButton.setEnabled(false);
        statusText.setText("Verification ho rahi hai...");

        PhoneAuthCredential credential =
                PhoneAuthProvider.getCredential(verificationId, code);
        signInWithCredential(credential);
    }

    private void signInWithCredential(PhoneAuthCredential credential) {
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        showLoggedInScreen();
                    } else {
                        if (verifyOtpButton != null) verifyOtpButton.setEnabled(true);
                        statusText.setText("Login failed: " +
                                (task.getException() == null ? "Unknown error" : task.getException().getMessage()));
                    }
                });
    }

    private void showLoggedInScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));

        TextView title = text("LEARN WITH JKS", 28, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView welcome = text("Login successful!\\n\\nStudent Corner\\n\\nClasses • Study Material • Tests • Results", 20, false);
        welcome.setGravity(Gravity.CENTER);
        root.addView(welcome, new LinearLayout.LayoutParams(-1, -2));

        Button logout = new Button(this);
        logout.setText("Logout");
        root.addView(logout, new LinearLayout.LayoutParams(-1, dp(56)));

        setContentView(root);

        logout.setOnClickListener(v -> {
            auth.signOut();
            showLoginScreen();
        });
    }
}
