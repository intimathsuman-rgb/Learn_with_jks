# Learn With JKS - Firebase OTP Crash Fix

This version keeps the existing Firebase Phone Authentication setup and adds defensive handling around OTP verification so Firebase errors are shown on-screen instead of crashing the app.

Package: com.learnwithjks.app
Firebase project: learn-with-jks-a3d26

Build with the repository workflow using Java 17 and Gradle 8.9.
