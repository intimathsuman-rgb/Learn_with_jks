package com.learnwithjks.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.FirebaseTooManyRequestsException;

import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private static final String TAG = "LearnWithJKS";

    private FirebaseAuth auth;
    private EditText phoneInput;
    private EditText otpInput;
    private Button sendOtpButton;
    private Button verifyOtpButton;
    private TextView statusText;
    private String verificationId;
    private boolean signInInProgress = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            auth = FirebaseAuth.getInstance();
        } catch (Throwable e) {
            Log.e(TAG, "Firebase initialization failed", e);
            showFatalError("Firebase start nahi ho paaya. Internet aur Firebase configuration check karein.");
            return;
        }

        if (auth.getCurrentUser() != null) {
            showLoggedInScreen();
        } else {
            showLoginScreen();
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, float size, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(Color.BLACK);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setPadding(dp(8), dp(8), dp(8), dp(8));
        return tv;
    }

    private boolean activityUsable() {
        return !isFinishing() && !isDestroyed();
    }

    private void setStatus(String message) {
        if (!activityUsable()) return;
        runOnUiThread(() -> {
            if (statusText != null) statusText.setText(message);
        });
    }

    private void showLoginScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24));

        TextView title = text("LEARN WITH JKS", 28, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = text("Student Login", 20, true);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        phoneInput = new EditText(this);
        phoneInput.setHint("Mobile number (+91XXXXXXXXXX)");
        phoneInput.setInputType(InputType.TYPE_CLASS_PHONE);
        root.addView(phoneInput, new LinearLayout.LayoutParams(-1, dp(60)));

        sendOtpButton = new Button(this);
        sendOtpButton.setText("SEND OTP");
        root.addView(sendOtpButton, new LinearLayout.LayoutParams(-1, dp(56)));

        otpInput = new EditText(this);
        otpInput.setHint("Enter 6-digit OTP");
        otpInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        otpInput.setVisibility(View.GONE);
        root.addView(otpInput, new LinearLayout.LayoutParams(-1, dp(60)));

        verifyOtpButton = new Button(this);
        verifyOtpButton.setText("VERIFY OTP");
        verifyOtpButton.setVisibility(View.GONE);
        root.addView(verifyOtpButton, new LinearLayout.LayoutParams(-1, dp(56)));

        statusText = text("OTP login is ready.", 15, false);
        statusText.setGravity(Gravity.CENTER);
        root.addView(statusText, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);

        sendOtpButton.setOnClickListener(v -> safeSendOtp());
        verifyOtpButton.setOnClickListener(v -> safeVerifyOtp());
    }

    private void safeSendOtp() {
        try {
            sendOtp();
        } catch (Throwable e) {
            Log.e(TAG, "Unexpected error while sending OTP", e);
            if (sendOtpButton != null) sendOtpButton.setEnabled(true);
            setStatus("OTP start nahi ho paaya: " + friendlyError(e));
        }
    }

    private void sendOtp() {
        if (auth == null) {
            setStatus("Firebase available nahi hai.");
            return;
        }

        String phone = phoneInput == null ? "" : phoneInput.getText().toString().trim();

        if (!phone.startsWith("+91") || phone.length() != 13) {
            Toast.makeText(this, "Number +91 ke saath 10 digit mobile number likhein.", Toast.LENGTH_LONG).show();
            return;
        }

        sendOtpButton.setEnabled(false);
        setStatus("OTP bheja ja raha hai...");

        PhoneAuthOptions options = PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(phone)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(this)
                .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                    @Override
                    public void onVerificationCompleted(@NonNull PhoneAuthCredential credential) {
                        Log.d(TAG, "Phone verification completed automatically");
                        signInSafely(credential);
                    }

                    @Override
                    public void onVerificationFailed(@NonNull FirebaseException e) {
                        Log.e(TAG, "Phone verification failed", e);
                        if (!activityUsable()) return;
                        runOnUiThread(() -> {
                            if (sendOtpButton != null) sendOtpButton.setEnabled(true);
                            setStatus("OTP error: " + friendlyError(e));
                        });
                    }

                    @Override
                    public void onCodeSent(@NonNull String id,
                                           @NonNull PhoneAuthProvider.ForceResendingToken token) {
                        Log.d(TAG, "OTP code sent");
                        verificationId = id;
                        if (!activityUsable()) return;
                        runOnUiThread(() -> {
                            if (otpInput != null) otpInput.setVisibility(View.VISIBLE);
                            if (verifyOtpButton != null) {
                                verifyOtpButton.setVisibility(View.VISIBLE);
                                verifyOtpButton.setEnabled(true);
                            }
                            if (sendOtpButton != null) sendOtpButton.setEnabled(true);
                            setStatus("OTP aa gaya. OTP enter karke VERIFY dabayein.");
                        });
                    }

                    @Override
                    public void onCodeAutoRetrievalTimeOut(@NonNull String id) {
                        verificationId = id;
                        setStatus("OTP manually enter karke VERIFY dabayein.");
                    }
                })
                .build();

        try {
            PhoneAuthProvider.verifyPhoneNumber(options);
        } catch (Throwable e) {
            Log.e(TAG, "verifyPhoneNumber crashed", e);
            sendOtpButton.setEnabled(true);
            setStatus("OTP start error: " + friendlyError(e));
        }
    }

    private void safeVerifyOtp() {
        try {
            verifyOtp();
        } catch (Throwable e) {
            Log.e(TAG, "Unexpected OTP verification error", e);
            if (verifyOtpButton != null) verifyOtpButton.setEnabled(true);
            setStatus("Verification error: " + friendlyError(e));
        }
    }

    private void verifyOtp() {
        if (verificationId == null || verificationId.trim().isEmpty()) {
            setStatus("Pehle SEND OTP dabayein aur OTP aane dein.");
            return;
        }

        String code = otpInput == null ? "" : otpInput.getText().toString().trim();
        if (!code.matches("\\d{6}")) {
            Toast.makeText(this, "6 digit OTP enter karein.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (signInInProgress) return;
        signInInProgress = true;
        if (verifyOtpButton != null) verifyOtpButton.setEnabled(false);
        setStatus("Verification ho rahi hai...");

        PhoneAuthCredential credential;
        try {
            credential = PhoneAuthProvider.getCredential(verificationId, code);
        } catch (IllegalArgumentException e) {
            signInInProgress = false;
            if (verifyOtpButton != null) verifyOtpButton.setEnabled(true);
            setStatus("OTP verify nahi ho paaya. Naya OTP mangakar dobara try karein.");
            Log.e(TAG, "Invalid verification credential", e);
            return;
        }

        signInSafely(credential);
    }

    private void signInSafely(PhoneAuthCredential credential) {
        if (auth == null || credential == null || signInInProgress) {
            if (credential == null) setStatus("Verification credential nahi mila.");
            return;
        }

        signInInProgress = true;
        if (verifyOtpButton != null) verifyOtpButton.setEnabled(false);
        setStatus("Login ho raha hai...");

        try {
            auth.signInWithCredential(credential)
                    .addOnCompleteListener(this, task -> {
                        signInInProgress = false;

                        if (!activityUsable()) return;

                        if (task.isSuccessful()) {
                            Log.d(TAG, "Phone sign-in successful");
                            showLoggedInScreen();
                        } else {
                            if (verifyOtpButton != null) verifyOtpButton.setEnabled(true);
                            Exception error = task.getException();
                            Log.e(TAG, "Phone sign-in failed", error);
                            setStatus("Login failed: " + friendlyError(error));
                        }
                    });
        } catch (Throwable e) {
            signInInProgress = false;
            Log.e(TAG, "signInWithCredential crashed", e);
            if (verifyOtpButton != null) verifyOtpButton.setEnabled(true);
            setStatus("Login error: " + friendlyError(e));
        }
    }

    private String friendlyError(Throwable e) {
        if (e == null) return "Unknown error";
        if (e instanceof FirebaseAuthInvalidCredentialsException) {
            return "OTP galat ya expire ho gaya hai.";
        }
        if (e instanceof FirebaseTooManyRequestsException) {
            return "Bahut zyada requests ho gayi hain. Thodi der baad try karein.";
        }
        if (e instanceof FirebaseAuthException) {
            String code = ((FirebaseAuthException) e).getErrorCode();
            if (code != null && !code.isEmpty()) return code;
        }
        String message = e.getMessage();
        if (message == null || message.trim().isEmpty()) return e.getClass().getSimpleName();
        return message;
    }

    private void showLoggedInScreen() {
        signInInProgress = false;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));

        TextView title = text("LEARN WITH JKS", 28, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView welcome = text("Login successful!\n\nStudent Corner\n\nClasses • Study Material • Tests • Results", 20, false);
        welcome.setGravity(Gravity.CENTER);
        root.addView(welcome, new LinearLayout.LayoutParams(-1, -2));

        Button logout = new Button(this);
        logout.setText("LOGOUT");
        root.addView(logout, new LinearLayout.LayoutParams(-1, dp(56)));

        setContentView(root);

        logout.setOnClickListener(v -> {
            try {
                auth.signOut();
            } catch (Throwable e) {
                Log.e(TAG, "Logout error", e);
            }
            verificationId = null;
            signInInProgress = false;
            showLoginScreen();
        });
    }

    private void showFatalError(String message) {
        TextView tv = text("LEARN WITH JKS\n\n" + message, 18, false);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(24), dp(24), dp(24), dp(24));
        setContentView(tv);
    }
}
