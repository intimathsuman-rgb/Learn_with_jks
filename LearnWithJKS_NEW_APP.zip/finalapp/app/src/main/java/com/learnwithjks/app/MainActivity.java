package com.learnwithjks.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private FirebaseAuth auth;
    private EditText phoneInput, otpInput;
    private Button sendOtpButton, verifyOtpButton;
    private TextView statusText;
    private String verificationId;
    private boolean signInInProgress;

    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
    private TextView tv(String s,float size,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(25,25,25));
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setPadding(dp(8),dp(8),dp(8),dp(8)); return t;
    }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    private LinearLayout root(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(18),dp(18),dp(18),dp(18)); return r; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); auth=FirebaseAuth.getInstance(); if(auth.getCurrentUser()!=null) dashboard(); else login(); }

    private void login(){
        LinearLayout r=root(); r.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title=tv("LEARN WITH JKS",30,true); title.setGravity(Gravity.CENTER); r.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=tv("Student Login • Mobile + OTP",18,true); sub.setGravity(Gravity.CENTER); r.addView(sub,new LinearLayout.LayoutParams(-1,-2));
        phoneInput=new EditText(this); phoneInput.setHint("+91XXXXXXXXXX"); phoneInput.setInputType(InputType.TYPE_CLASS_PHONE); r.addView(phoneInput,new LinearLayout.LayoutParams(-1,dp(58)));
        sendOtpButton=btn("📱 SEND OTP"); r.addView(sendOtpButton,new LinearLayout.LayoutParams(-1,dp(54)));
        otpInput=new EditText(this); otpInput.setHint("6 digit OTP"); otpInput.setInputType(InputType.TYPE_CLASS_NUMBER); otpInput.setVisibility(View.GONE); r.addView(otpInput,new LinearLayout.LayoutParams(-1,dp(58)));
        verifyOtpButton=btn("✅ VERIFY & LOGIN"); verifyOtpButton.setVisibility(View.GONE); r.addView(verifyOtpButton,new LinearLayout.LayoutParams(-1,dp(54)));
        statusText=tv("OTP login ready.",14,false); statusText.setGravity(Gravity.CENTER); r.addView(statusText,new LinearLayout.LayoutParams(-1,-2));
        TextView note=tv("Your account is secured with Firebase Phone Authentication.",13,false); note.setGravity(Gravity.CENTER); r.addView(note,new LinearLayout.LayoutParams(-1,-2));
        setContentView(r); sendOtpButton.setOnClickListener(v->sendOtp()); verifyOtpButton.setOnClickListener(v->verifyOtp());
    }
    private void status(String s){ if(statusText!=null)statusText.setText(s); }
    private void sendOtp(){
        String p=phoneInput.getText().toString().trim(); if(!p.matches("\\+91\\d{10}")){status("+91 ke saath 10 digit mobile number likhein.");return;}
        sendOtpButton.setEnabled(false); status("OTP bheja ja raha hai...");
        PhoneAuthOptions o=PhoneAuthOptions.newBuilder(auth).setPhoneNumber(p).setTimeout(60,TimeUnit.SECONDS).setActivity(this)
            .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
                @Override public void onVerificationCompleted(@NonNull PhoneAuthCredential c){ signIn(c); }
                @Override public void onVerificationFailed(@NonNull FirebaseException e){ sendOtpButton.setEnabled(true); status("OTP error: "+friendly(e)); }
                @Override public void onCodeSent(@NonNull String id,@NonNull PhoneAuthProvider.ForceResendingToken t){ verificationId=id; otpInput.setVisibility(View.VISIBLE); verifyOtpButton.setVisibility(View.VISIBLE); sendOtpButton.setEnabled(true); status("OTP aa gaya. OTP enter karein."); }
            }).build(); PhoneAuthProvider.verifyPhoneNumber(o);
    }
    private void verifyOtp(){ if(verificationId==null){status("Pehle OTP mangayein.");return;} String c=otpInput.getText().toString().trim(); if(!c.matches("\\d{6}")){status("6 digit OTP enter karein.");return;} if(signInInProgress)return; signInInProgress=true; verifyOtpButton.setEnabled(false); signIn(PhoneAuthProvider.getCredential(verificationId,c)); }
    private void signIn(PhoneAuthCredential c){ auth.signInWithCredential(c).addOnCompleteListener(this,t->{signInInProgress=false;if(t.isSuccessful())dashboard();else{verifyOtpButton.setEnabled(true);status("Login failed: "+friendly(t.getException()));}}); }
    private String friendly(Exception e){ if(e instanceof FirebaseAuthInvalidCredentialsException)return "OTP galat ya expire ho gaya."; if(e instanceof FirebaseTooManyRequestsException)return "Bahut requests. Thodi der baad try karein."; return e==null?"Unknown error":String.valueOf(e.getMessage()); }

    private void dashboard(){
        LinearLayout r=root();
        TextView head=tv("LEARN WITH JKS",27,true); head.setGravity(Gravity.CENTER); r.addView(head,new LinearLayout.LayoutParams(-1,-2));
        String phone=auth.getCurrentUser()==null?"Student":"Student • "+auth.getCurrentUser().getPhoneNumber(); TextView w=tv("Welcome 👋\n"+phone,16,false); w.setGravity(Gravity.CENTER); r.addView(w,new LinearLayout.LayoutParams(-1,-2));
        addMenu(r,"📚  CLASSES / BATCHES","View your classes and live-class schedule",v->classes());
        addMenu(r,"📄  STUDY MATERIAL","PDFs, notes, images and videos",v->materials());
        addMenu(r,"📝  TESTS / QUIZZES","Scheduled tests, practice and mock tests",v->tests());
        addMenu(r,"🏆  RESULTS","Scores and result history",v->results());
        addMenu(r,"🔐  OWNER / ADMIN","Manage classes, material and tests",v->owner());
        Button logout=btn("Logout"); r.addView(logout,new LinearLayout.LayoutParams(-1,dp(50))); logout.setOnClickListener(v->{auth.signOut();login();});
        setContentView(r);
    }
    private void addMenu(LinearLayout r,String title,String sub,View.OnClickListener l){
        Button b=btn(title+"\n"+sub); b.setTextSize(15); b.setGravity(Gravity.CENTER_VERTICAL); b.setOnClickListener(l); r.addView(b,new LinearLayout.LayoutParams(-1,dp(70)));
    }
    private void page(String title,String body){
        LinearLayout r=root(); TextView h=tv(title,25,true); h.setGravity(Gravity.CENTER); r.addView(h,new LinearLayout.LayoutParams(-1,-2));
        TextView c=tv(body,17,false); c.setPadding(dp(12),dp(20),dp(12),dp(20)); r.addView(c,new LinearLayout.LayoutParams(-1,-2)); Button back=btn("← Back to Dashboard"); r.addView(back,new LinearLayout.LayoutParams(-1,dp(52))); back.setOnClickListener(v->dashboard()); setContentView(r);
    }
    private void classes(){ page("📚 Classes / Batches","RAJASTHAN GK • Batch 2026\n\nToday\n• Live Class: Rajasthan Economic Review\n• Time: 7:00 PM\n\nUpcoming\n• Current Affairs\n• Reasoning\n• Rajasthan History\n\nLive class links can be connected from the Owner panel in the next backend phase."); }
    private void materials(){ page("📄 Study Material","Available Material\n\n1. Rajasthan Economic Review 2026-27.pdf\n2. Rajasthan GK Notes.pdf\n3. Current Affairs — October\n4. Class 10 Mathematics Notes\n\nPDF/file storage is prepared as a module; actual cloud files will be connected through Firebase Storage/Firestore."); }
    private void tests(){ page("📝 Tests / Quizzes","Scheduled Tests\n\n🎯 Rajasthan GK Test — 10 Oct, 7:00 PM\nQuestions: 25 • Duration: 20 min\n\n🎯 Current Affairs Quiz — 12 Oct, 8:00 PM\nQuestions: 20 • Duration: 15 min\n\nPractice Test\n• Start a demo quiz\n\nQuestion bank and automatic result calculation will be connected to the Owner backend."); }
    private void results(){ page("🏆 Results","Your Results\n\nRajasthan GK Test — 18/25\nCurrent Affairs Quiz — 16/20\nPractice Test — Not attempted\n\nResult history is ready for the student dashboard; cloud history will be connected to Firestore."); }
    private void owner(){
        LinearLayout r=root(); TextView h=tv("🔐 Owner / Admin",25,true); h.setGravity(Gravity.CENTER); r.addView(h,new LinearLayout.LayoutParams(-1,-2));
        TextView n=tv("Owner area\n\nManage:\n• Students\n• Classes / Batches\n• PDFs / Study Material\n• Live Classes\n• Tests & Questions\n• Test schedule\n• Student Results\n\nThis screen is the UI foundation. Real secure owner authentication and Firestore permissions must be connected before production use.",17,false); r.addView(n,new LinearLayout.LayoutParams(-1,-2)); Button back=btn("← Back"); r.addView(back,new LinearLayout.LayoutParams(-1,dp(52))); back.setOnClickListener(v->dashboard()); setContentView(r);
    }
}
