# Learn With JKS — New App Build

This build adds the planned student dashboard modules on top of Firebase Phone OTP:
- Student mobile + OTP login
- Classes / batches
- Study material module
- Scheduled tests / quizzes module
- Results module
- Owner/Admin UI foundation

Important: the dashboard data in this version is demo/local UI. Production cloud data, secure Owner authentication, Firestore rules, Firebase Storage files, live-class links and real question-bank scheduling still need backend wiring.
